import SwiftUI

struct TipEntry: Identifiable {        // Defining the data structure
    let id = UUID()                    // Each TipEntry gets a unique id
    let billAmount: Double             // Stores the bill amount entered by the user
    let tips: [Double]                 // Stores a list of tip values
    let tipPercents: [Double]           // Stores the tip percentages used
    let billNumber: Int                 // Stores the permanent bill number
}

struct ContentView: View {
    @State private var billInput: String = ""         // Tracks user input and updates the view
    @State private var tipHistory: [TipEntry] = []     // Stores all previous TipEntry objects
    @State private var errorMessage: String = ""       // Message shown if input is wrong
    @State private var successMessage: String = ""     // Message shown if input is correct
    @State private var billCount: Int = 0              // Counts how many bills have been added
    
    let tipPercents = [0.15, 0.18, 0.20]                // Default tip percentages
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Tip Calculator")
                .font(.largeTitle)
                .bold()
                .padding(.top)
            
            TextField("Enter bill amount", text: $billInput)   // Input text box
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(.decimalPad)
                .padding()
            
            // Display error message if input is invalid
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.subheadline)
            }
            
            // Display success message if input is valid
            if !successMessage.isEmpty {
                Text(successMessage)
                    .foregroundColor(.green)
                    .font(.subheadline)
            }
            
            Button("Calculate Tips") {            // Button labeled "Calculate Tips"
                if let bill = Double(billInput) {  // Tries to convert input
                    errorMessage = ""              // Clear any error
                    successMessage = "Bill added to history!"  // Show success message
                    calculateTips(billAmount: bill)
                } else {
                    successMessage = ""            // Clear success message
                    errorMessage = "Wrong input!"  // Show error if input invalid
                }
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
            
            List(tipHistory) { entry in             //Creates a scrollable list that loops through every TipEntry stored in tipHistory. entry is each individual TipEntry  
                VStack(alignment: .leading) {
                    Text(String(format: "%d. Bill: $%.2f", entry.billNumber, entry.billAmount))  // Shows 1. Bill, 2. Bill, etc.
                        .font(.headline)
                    
                    ForEach(entry.tips.indices, id: \.self) { index in          //Loop over each tip inside the tips array of the entry, indices gives you 0, 1, 2 for the three tips and each index is unique
                        Text(String(format: "Tip (%.0f%%): $%.2f", entry.tipPercents[index] * 100, entry.tips[index]))
                            .font(.subheadline)        //Shows each tip percentage and calculated tip value. Ex: "Tip (15%): $3.75"
                    }
                }
            }
        }
        .padding()
    }
    
    func calculateTips(billAmount: Double) {         // Calculates tips and stores them
        var tips: [Double] = []                     // Empty array to store calculated tips
        let selectedTipPercents: [Double]            // Tip percentages based on bill size
        
        if billAmount < 20 {
            selectedTipPercents = [0.05, 0.10, 0.15] // Smaller percentages for small bills
        } else {
            selectedTipPercents = tipPercents        // Normal percentages
        }
        
        for percent in selectedTipPercents {         // Loop through each selected percentage
            tips.append(billAmount * percent)        // Calculate and store the tip
        }
        
        billCount += 1  // Increment bill count after successful input
        
        let newEntry = TipEntry(
            billAmount: billAmount,
            tips: tips,
            tipPercents: selectedTipPercents,
            billNumber: billCount  // Set the permanent bill number
        )
        
        tipHistory.insert(newEntry, at: 0)  // Insert at the beginning of the history
        billInput = ""                      // Clear input after adding
    }
}

#Preview {
    ContentView()
}
